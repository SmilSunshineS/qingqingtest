$(function() {
	
	//查看更多消息
//  $('.more_news').click(function() {
//  	$('.content').css({"overflow-y" : "auto"});
//  });
    
//模态框
$('.model_del').mouseover(function() {
	$(this).attr('src','Public/home/img/model_del_on.png')
});
$('.model_del').mouseout(function() {
	$(this).attr('src','Public/home/img/model_del.png')
});

$('.model_del').click(function() {
	$('#model').hide();
});

$('.contect_content').on('click', '.imgs', function() {
	$('#model').show();
	var imgs_url = $(this).attr('src');
	$('.model_img').attr('src',imgs_url);
})
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
})
